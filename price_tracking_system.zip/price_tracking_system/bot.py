from telegram import (
    Update,
    InlineKeyboardButton,
    InlineKeyboardMarkup
)

from telegram.ext import (
    ApplicationBuilder,
    CommandHandler,
    ContextTypes,
    CallbackQueryHandler
)

from fetcher import get_latest_gold


"""
FOR GOLD COMMAND/BUTTON, USER PRESSES, BOT WILL SEND DATA
"""
async def send_gold(update: Update, context: ContextTypes.DEFAULT_TYPE):
    gold = get_latest_gold()

    message = (
        "📌 Item: GOLD\n"
        f"📅 Date: {gold['date']}\n"
        f"💲 Price: {gold['price']}\n"
        f"📡 Source: {gold['source']}"
    )

    keyboard = [
        [InlineKeyboardButton("🔙 Go back", callback_data="metals")]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    await update.callback_query.edit_message_text(
        text=message,
        parse_mode=None,
        reply_markup=reply_markup
    )








"""
FOR START COMMAND, USER PRESSES, BOT WILL SEND GREETING MESSAGE AND PHOTO
"""
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):


    keyboard = [
        [
            InlineKeyboardButton("ℹ️ Info", callback_data = "info"),
            InlineKeyboardButton("📊 Market", callback_data = "market")
        ]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)


    greet_text = (
        "🚀 Welcome to Market Price Tracker Bot!\n"
        "Prices update real-time-ish. Data from reliable sources,\n"
        "Enjoy ;)"
    )

    await update.message.reply_text(
        text = greet_text,
        parse_mode = None,
        reply_markup = reply_markup
        )





"""
FOR BUTTON HANDLER
"""
async def button_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()

    if query.data == "market":
        keyboard = [
            [InlineKeyboardButton("🪙 Metals", callback_data="metals")],
            [InlineKeyboardButton("🔙 Go back", callback_data="start")]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        await query.edit_message_text(
            "📊 *Market*\n\nSelect a category:",
            parse_mode=None,
            reply_markup=reply_markup
        )



    elif query.data == "start":
        keyboard = [
            [
                InlineKeyboardButton("ℹ️ Info", callback_data="info"),
                InlineKeyboardButton("📊 Market", callback_data="market")
            ]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        await query.edit_message_text(
            text="🚀 Welcome back! Choose an option:",
            parse_mode=None,
            reply_markup=reply_markup
        )

    

    elif query.data == "info":
        keyboard = [
            [InlineKeyboardButton("🔙 Go back", callback_data="start")]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)

        await query.edit_message_text(
            "ℹ️ *Info*\n\n"
            "This bot tracks market prices and provides quick updates.",
            parse_mode=None,
            reply_markup=reply_markup
        )


    elif query.data == "metals":
        keyboard = [
            [InlineKeyboardButton("🥇 Gold", callback_data="gold")],
            [InlineKeyboardButton("🔙 Go back", callback_data="market")]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        await query.edit_message_text(
            "🪙 *Metals*\n\nSelect an asset:",
            parse_mode=None,
            reply_markup=reply_markup
        )
    elif query.data == "gold":
        await send_gold(update, context)






























































app = ApplicationBuilder().token("8367806982:AAFx3MV7P1NOfIaeKIQkseP3GKfuo7S4rAs").build()
app.add_handler(CommandHandler("start", start))
app.add_handler(CallbackQueryHandler(button_handler))
app.run_polling()