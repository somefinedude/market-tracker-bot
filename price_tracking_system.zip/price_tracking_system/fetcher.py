import requests
from datetime import datetime

def get_latest_gold():
    url = "https://freegoldapi.com/data/latest.json"
    
    response = requests.get(url, timeout=6)

    response.raise_for_status()

    data = response.json()


    yahoo_data = [
        d for d in data
        if d.get("source") == "yahoo_finance"
    ]
    if not yahoo_data:
            raise ValueError("No modern data available!")
    

    latest = max(
          yahoo_data,
          key = lambda x: datetime.strptime(x["date"], "%Y-%m-%d")
    )

    
    return latest